Ryan Blocker - HW5

Hey sorry for the long file I attempted to make three separate header but my computer was being a little weird

You can compile the file with `make` and then run it with `./Scheduler <input file>`

To reset the file structure you can type `make clean` and then `make all` to re-compile