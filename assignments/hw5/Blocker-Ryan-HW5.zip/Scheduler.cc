//HW5 - Created by Ryan Blocker 11/6/23

//Dependencies
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <queue>
#include <sstream>
#include <iomanip>
#include <algorithm>

using namespace std;

//process structure for data table
struct Process {
    int id;
    int burstTime;
    int priority;
    int arrivalTime;
};


struct CompareBurstTime {
    bool operator()(Process const& p1, Process const& p2) {
        return p1.burstTime > p2.burstTime;
    }
};

struct ComparePriority {
    bool operator()(const Process& p1, const Process& p2) {
        if (p1.priority != p2.priority) return p1.priority > p2.priority;
        return p1.arrivalTime > p2.arrivalTime;
    }
};

void firstComeFirstServe(vector<vector<int>> data) {

    //sort data table by arrive time
    sort(data.begin(), data.end(), [](const vector<int>& a, const vector<int>& b) {
        return a[1] < b[1];
    });

    vector<int> wt(data.size(), 0); //wait time
    vector<int> tat(data.size(), 0); //turnaround time

    float total_tat = 0; //total time
    float total_wt = 0; //total wait time

    int current_time = 0; //set current time

    for(size_t i = 0; i < data.size(); ++i) { 
        if(i == 0 || current_time < data[i][1]) { 
            current_time = data[i][1]; 
        }
        wt[i] = current_time - data[i][1]; 
        current_time += data[i][2]; 
        tat[i] = wt[i] + data[i][2]; 
        total_wt += wt[i];
        total_tat += tat[i]; 
    }

    float avg_wt = total_wt / data.size(); 
    float avg_tat = total_tat / data.size(); 

    int total_time = current_time - data[0][1]; 
    float throughput = static_cast<float>(data.size()) / total_time; 
    //set sig figs and return results
    cout << fixed << setprecision(3);
    cout << "\n--- FCFS ---\n";
    cout << "Average Turnaround Time: " << avg_tat << "\n";
    cout << "Average Waiting Time: " << avg_wt << "\n";
    cout << "Throughput: " << throughput << "\n";
}

void shortestJobFirst(const vector<vector<int>>& data) {
    //made a copy so it can be modified
    vector<vector<int>> dataCopy = data;

    sort(dataCopy.begin(), dataCopy.end(), [](const vector<int>& a, const vector<int>& b) {
        return a[1] < b[1];
    });

    priority_queue<Process, vector<Process>, CompareBurstTime> pq;
    vector<int> remainingBurstTime(dataCopy.size(), 0);
    vector<int> arrivalTime(dataCopy.size());
    vector<int> completionTime(dataCopy.size(), 0);
    vector<int> totalWaitingTime(dataCopy.size(), 0);
    vector<bool> hasArrived(dataCopy.size(), false);
    vector<bool> isCompleted(dataCopy.size(), false);

    for(size_t i = 0; i < dataCopy.size(); ++i) {
        remainingBurstTime[i] = dataCopy[i][2];
        arrivalTime[i] = dataCopy[i][1];
    }

    int currentTime = dataCopy[0][1];
    int currentProcessId = -1;
    int completedProcesses = 0;

    while(completedProcesses < static_cast<int>(dataCopy.size())) {
        for(size_t i = 0; i < dataCopy.size(); ++i) {
            if(arrivalTime[i] <= currentTime && !hasArrived[i]) {
                Process newProcess = {
                    static_cast<int>(i),
                    dataCopy[i][2],      
                    0,                   
                    dataCopy[i][1]       
                };
                pq.push(newProcess);
                hasArrived[i] = true;
            }
        }

        // Check if the current process is done
        if(currentProcessId != -1 && remainingBurstTime[currentProcessId] == 0) {
            completionTime[currentProcessId] = currentTime;
            totalWaitingTime[currentProcessId] = completionTime[currentProcessId] - arrivalTime[currentProcessId] - dataCopy[currentProcessId][2];
            isCompleted[currentProcessId] = true;
            completedProcesses++;
            currentProcessId = -1;
        }

        if(currentProcessId == -1 && !pq.empty()) {
            Process nextProcess = pq.top();
            pq.pop();
            currentProcessId = nextProcess.id;
        }

        if(currentProcessId != -1) {
            remainingBurstTime[currentProcessId]--;
        }

        for(size_t i = 0; i < dataCopy.size(); ++i) {
            if(hasArrived[i] && !isCompleted[i] && static_cast<int>(i) != currentProcessId) {
                totalWaitingTime[i]++;
            }
        }

        currentTime++;
    }

    // calculate metrics
    float totalTurnaroundTime = 0;
    float totalWaitingTimeSum = 0;
    for(size_t i = 0; i < dataCopy.size(); ++i) {
        float turnaroundTime = completionTime[i] - arrivalTime[i];
        totalTurnaroundTime += turnaroundTime;
        totalWaitingTimeSum += totalWaitingTime[i];
    }

    float averageTurnaroundTime = totalTurnaroundTime / dataCopy.size();
    float averageWaitingTime = totalWaitingTimeSum / dataCopy.size();
    float throughput = static_cast<float>(dataCopy.size()) / (currentTime - dataCopy[0][1]);

    cout << fixed << setprecision(3);
    cout << "\n--- SJFP ---\n";
    cout << "Average Turnaround Time: " << averageTurnaroundTime << "\n";
    cout << "Average Waiting Time: " << averageWaitingTime << "\n";
    cout << "Throughput: " << throughput << "\n";
}

void priorityScheduling(const vector<vector<int>>& data) {
    vector<vector<int>> dataCopy = data;
    sort(dataCopy.begin(), dataCopy.end(), [](const vector<int>& a, const vector<int>& b) {
        return a[1] < b[1];
    });

    priority_queue<Process, vector<Process>, ComparePriority> pq;
    vector<int> remainingBurstTime(dataCopy.size());
    vector<int> arrivalTime(dataCopy.size());
    vector<int> completionTime(dataCopy.size(), 0);
    vector<int> totalWaitingTime(dataCopy.size(), 0);
    vector<bool> hasArrived(dataCopy.size(), false);
    vector<bool> isCompleted(dataCopy.size(), false);

    for(size_t i = 0; i < dataCopy.size(); ++i) {
        remainingBurstTime[i] = dataCopy[i][2];
        arrivalTime[i] = dataCopy[i][1];
    }

    int currentTime = dataCopy[0][1];
    int currentProcessId = -1;
    int completedProcesses = 0;

    while(completedProcesses < static_cast<int>(dataCopy.size())) {
    for(size_t i = 0; i < dataCopy.size(); ++i) {
        if(arrivalTime[i] <= currentTime && !hasArrived[i]) {
            Process newProcess = {
                static_cast<int>(i),
                dataCopy[i][2],      
                dataCopy[i][3],      
                dataCopy[i][1]       
            };
            pq.push(newProcess);
            hasArrived[i] = true;
        }
    }

        if(currentProcessId != -1 && remainingBurstTime[currentProcessId] == 0) {
            completionTime[currentProcessId] = currentTime;
            totalWaitingTime[currentProcessId] = completionTime[currentProcessId] - arrivalTime[currentProcessId] - dataCopy[currentProcessId][2];
            isCompleted[currentProcessId] = true;
            completedProcesses++;
            currentProcessId = -1;
        }

        if(currentProcessId == -1 && !pq.empty()) {
            Process nextProcess = pq.top();
            pq.pop();
            currentProcessId = nextProcess.id;
        }

        if(currentProcessId != -1) {
            remainingBurstTime[currentProcessId]--;
        }

        for(size_t i = 0; i < dataCopy.size(); ++i) {
            if(hasArrived[i] && !isCompleted[i] && static_cast<int>(i) != currentProcessId) {
                totalWaitingTime[i]++;
            }
        }

        currentTime++;
    }

    // calculate metrics
    float totalTurnaroundTime = 0;
    float totalWaitingTimeSum = 0;
    for(size_t i = 0; i < dataCopy.size(); ++i) {
        float turnaroundTime = completionTime[i] - arrivalTime[i];
        totalTurnaroundTime += turnaroundTime;
        totalWaitingTimeSum += totalWaitingTime[i];
    }

    float averageTurnaroundTime = totalTurnaroundTime / dataCopy.size();
    float averageWaitingTime = totalWaitingTimeSum / dataCopy.size();
    float throughput = static_cast<float>(dataCopy.size()) / (currentTime - dataCopy[0][1]);

    cout << fixed << setprecision(3);
    cout << "\n--- Priority ---\n";
    cout << "Average Turnaround Time: " << averageTurnaroundTime << "\n";
    cout << "Average Waiting Time: " << averageWaitingTime << "\n";
    cout << "Throughput: " << throughput << "\n\n";

}

int main(int argc, char* argv[]) {

    cout << "\nHW5 - Created by Ryan Blocker\n";
    
    //ERROR CHECK 1: Did not provide input file
    if(argc != 2 || argc > 3) {
        cerr << "\nERROR 1: You did not provide an input argument. Please provide only one file for testing.\n\n";
        exit(1);
    }
    
    //open given file
    ifstream inputFile;
    inputFile.open(argv[1]);

    //ERROR CHECK 2: Did not provide input file
    if(!inputFile.is_open()) {
        cerr << "\nERROR 2: The file (" << argv[1] << ") provided could not be opened.\n\n";
        exit(2);
    }

    //create data vector
    vector<vector<int>> data;
    string line;
    
    //read file into datalists
    while (getline(inputFile, line)) {
        vector<int> row;
        stringstream lineStream(line);
        string cell;

        while(getline(lineStream, cell, ',')) {
            row.push_back(stoi(cell));
        }

        data.push_back(row);
    }

    //ERROR CHECK 3: Data Table is Empty
    if(data.empty()) {
        cerr << "\nERROR 3: The data table is empty. Check your input file.\n\n";
        exit(3);
    }

    //run algorithms with data table
    firstComeFirstServe(data);
    shortestJobFirst(data);
    priorityScheduling(data);

    inputFile.close();
    return 0;

}