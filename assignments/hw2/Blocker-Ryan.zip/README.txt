Here is my HW2 for CS370 by Ryan Blocker (833058080)

To run the project type: make all

Then run ./coordinator <divisor> <dividend1> <dividend2> <dividend3> <dividend4>

Then to refresh you can type: make clean

Thank you so much!!