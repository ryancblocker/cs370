HW4 Producer-Consumer by Ryan Blocker (833058080)
Date - 10/11/23

You can compile the program using the provided Makefile:
$ make

Run the program using the Java Runtime Environment:
$ java ProducerConsumer

To clean up the compiled .class files:
$ make clean

Thank you!