import java.util.Random;

public class ProducerConsumer {
    public static void main(String[] args) {
        Buffer buffer = new Buffer();
        Producer producer = new Producer(buffer);
        Consumer consumer = new Consumer(buffer);
        
        Thread producerThread = new Thread(producer);
        Thread consumerThread = new Thread(consumer);
        
        //Credentials
        System.out.println("\nHW4 - Ryan Blocker (833058080)\n");
        
        producerThread.start();
        consumerThread.start();
    }
}

class Buffer {
    private static final int CAPACITY = 1000;
    private Double[] buffer = new Double[CAPACITY];
    private int front = 0;
    private int rear = 0;
    private int count = 0;
    private double bufferValueCounter = 0.0;
    
    public synchronized void add(Double item) throws InterruptedException {
        while (count == CAPACITY) {
            //TESTING: Producer Waits for the Consumer
            //System.out.println("Buffer full! Producer is waiting...");
            wait();
        }
        
        buffer[rear] = item;
        rear = (rear + 1) % CAPACITY;
        count++;
        bufferValueCounter += item;
        notifyAll();
    }
    
    public synchronized Double remove() throws InterruptedException {
        while (count == 0) {
             //TESTING: Consumer waits for the producer
             //System.out.println("Buffer empty! Consumer is waiting...");
            wait();
        }
        
        Double item = buffer[front];
        front = (front + 1) % CAPACITY;
        count--;
        bufferValueCounter -= item;
        notifyAll();
        
        return item;
    }
    
    public double getBufferValueCounter() {
        return bufferValueCounter;
    }
}

class Producer implements Runnable {
    private Buffer buffer;
    private static final int TOTAL_ITEMS = 1000000;
    private double generatedValueCounter = 0.0;
    
    public Producer(Buffer buffer) {
        this.buffer = buffer;
    }
    
    @Override
    public void run() {
        Random random = new Random();
        for (int i = 0; i < TOTAL_ITEMS; i++) {
            try {
                Double bufferElement = random.nextDouble() * 100.0;
                buffer.add(bufferElement);
                generatedValueCounter += bufferElement;
                if ((i + 1) % 100000 == 0) {
                    System.out.println("Producer: Generated " + (i + 1) + " items, Cumulative value of generated items=" + String.format("%.3f", generatedValueCounter));

                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Producer: Finished generating " + TOTAL_ITEMS + " items");
    }
}

class Consumer implements Runnable {
    private Buffer buffer;
    private static final int TOTAL_ITEMS = 1000000;
    private double consumedValueCounter = 0.0;
    
    public Consumer(Buffer buffer) {
        this.buffer = buffer;
    }
    
    @Override
    public void run() {
        for (int i = 0; i < TOTAL_ITEMS; i++) {
            try {
                Double item = buffer.remove();
                consumedValueCounter += item;
                if ((i + 1) % 100000 == 0) {
                    System.out.println("Consumer: Consumed " + (i + 1) + " items, Cumulative value of consumed items=" + String.format("%.3f", consumedValueCounter));

                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Consumer: Finished consuming " + TOTAL_ITEMS + " items");
    }
}
